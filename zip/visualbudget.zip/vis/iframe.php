<?php

header("Content-type: text/html");

?><!DOCTYPE html>
<html>
<head>
<link rel='stylesheet' type='text/css' href='vb.min.css'>
<script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/d3/4.2.6/d3.min.js'></script>
<script type='text/javascript' src='https://cdnjs.cloudflare.com/ajax/libs/jquery/1.12.4/jquery.js'></script>
<script type='text/javascript' src='vb.min.js'></script>
</head>
<body><?php
echo $chart_element;
?></body>
</html>